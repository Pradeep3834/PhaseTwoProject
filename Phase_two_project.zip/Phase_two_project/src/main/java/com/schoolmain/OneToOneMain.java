package com.schoolmain;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.teacherslist.Subjects;
import com.teacherslist.Teachers;

public class OneToOneMain {

	public static void main(String[] args) {
		Configuration configuration = new Configuration().configure();
		StandardServiceRegistryBuilder builder= new StandardServiceRegistryBuilder()
			
				.applySettings(configuration.getProperties());
		SessionFactory factory=configuration.buildSessionFactory(builder.build());
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		
		Subjects s1= new Subjects("Trignometry");
		Subjects s2= new Subjects("Geography");
		Subjects s3= new Subjects("Civics");
		
		Teachers t1= new Teachers("Pradeep", s1);
		Teachers t2= new Teachers("Sampath", s2);
		Teachers t3= new Teachers("Sai", s3);


		session.save(s1);
		session.save(s2);
		session.save(s3);		
		session.save(t1);
		session.save(t2);
		session.save(t3);
	
		
		transaction.commit();
		session.close();
		factory.close();
	}
}


	