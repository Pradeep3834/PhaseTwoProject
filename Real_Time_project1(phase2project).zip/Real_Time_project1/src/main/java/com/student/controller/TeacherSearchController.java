package com.student.controller;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.student.model.Teachers;
import com.student.service.TeachersService;
import com.student.service.impl.TeachersServiceImpl;

@Path("/teachers")
public class TeacherSearchController {
	
	private TeachersService service=new TeachersServiceImpl();
	
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Teachers> getAllTeachers(){
		return service.getAllTeachers();
	}

}
