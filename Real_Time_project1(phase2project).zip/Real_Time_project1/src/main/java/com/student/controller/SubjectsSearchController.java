package com.student.controller;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.student.model.Subjects;
import com.student.service.SubjectsService;
import com.student.service.impl.SubjectsServiceImpl;
@Path("/subjects")
public class SubjectsSearchController {
private SubjectsService service=new SubjectsServiceImpl();
	
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Subjects> getAllSubjects(){
		return service.getAllSubjects();
	}
}
