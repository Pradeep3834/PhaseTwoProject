package com.student.controller;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.student.model.Classes;
import com.student.service.ClassesService;
import com.student.service.impl.ClassesServiceImpl;
@Path("/classes")
public class ClassesSearchController {
private ClassesService service=new ClassesServiceImpl();
	
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Classes> getAllClasses(){
		return service.getAllClasses();
	}
}
