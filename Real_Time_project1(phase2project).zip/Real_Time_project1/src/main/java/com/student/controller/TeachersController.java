package com.student.controller;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.student.exception.BusinessException;
import com.student.model.Teachers;
import com.student.service.TeachersService;
import com.student.service.impl.TeachersServiceImpl;
@Path("/teacher")
public class TeachersController {
private TeachersService service = new TeachersServiceImpl();
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Teachers createTeachers(Teachers teachers) {
		
		try {
			return service.createTeachers(teachers);
		} catch (BusinessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

		
	@Path("/{id}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Teachers getTeachersById(@PathParam("id")int id) {
		
		try {
			return service.getTeachersById(id);
		} catch (BusinessException e) {
			return getTeachersById(id);
		}
	
	}
	

}
