package com.student.controller;

import java.util.List;


import javax.ws.rs.GET;
import javax.ws.rs.Path;

import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.student.model.Student;
import com.student.service.StudentService;
import com.student.service.impl.StudentServiceImpl;


@Path("/students")
public class StudentSearchController {
private StudentService service=new StudentServiceImpl();
	
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Student> getAllStudents(){
		return service.getAllStudents();
	}
	
	
	
}