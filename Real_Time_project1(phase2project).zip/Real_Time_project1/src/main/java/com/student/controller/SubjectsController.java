package com.student.controller;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.student.exception.BusinessException;
import com.student.model.Subjects;
import com.student.service.SubjectsService;
import com.student.service.impl.SubjectsServiceImpl;
@Path("/subjects")
public class SubjectsController {
private SubjectsService service = new SubjectsServiceImpl();
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Subjects createStudent(Subjects subjects) {
		
		try {
			return service.createSubjects(subjects);
		} catch (BusinessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

		
	@Path("/{id}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Subjects getSubjectsById(@PathParam("id")int id) {
		
		try {
			return service.getSubjectsById(id);
		} catch (BusinessException e) {
			return getSubjectsById(id);
		}
		
	

	}
	
}

