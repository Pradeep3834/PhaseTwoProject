package com.student.service;

import java.util.List;

import com.student.exception.BusinessException;
import com.student.model.Teachers;

public interface TeachersService {
	public Teachers createTeachers(Teachers teachers) throws BusinessException;
	public Teachers getTeachersById(int id) throws BusinessException;
	public List<Teachers> getAllTeachers();
	
}
