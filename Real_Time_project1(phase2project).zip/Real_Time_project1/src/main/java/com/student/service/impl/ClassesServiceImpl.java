package com.student.service.impl;

import java.util.List;

import com.student.dao.ClassesDAO;
import com.student.dao.impl.ClassesDAOImpl;
import com.student.exception.BusinessException;
import com.student.model.Classes;
import com.student.service.ClassesService;

public class ClassesServiceImpl implements ClassesService{
	private ClassesDAO classesDAO=new ClassesDAOImpl();
	@Override
	public Classes createClasses(Classes classes) throws BusinessException {
		
		return classesDAO.createClasses(classes);
	}

	@Override
	public Classes getClassesById(int id) throws BusinessException {
		if(id<=0||id>100) {
			throw new BusinessException("entered id "+id+" invalid");
		}
		return classesDAO.getClassesById(id);
	}
	

	@Override
	public Classes updateStudent(Classes classes) throws BusinessException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Classes> getAllClasses() {
		
		return classesDAO.getAllClasses();
	}

	@Override
	public List<Classes> getClassesByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}


	
}

