package com.student.service;

import java.util.List;

import com.student.exception.BusinessException;
import com.student.model.Classes;

public interface ClassesService {
	public Classes createClasses(Classes classes) throws BusinessException;
	public Classes getClassesById(int id) throws BusinessException;
	public Classes updateStudent(Classes classes) throws BusinessException;
	public List<Classes> getAllClasses();
	public List<Classes> getClassesByName(String name);
}
