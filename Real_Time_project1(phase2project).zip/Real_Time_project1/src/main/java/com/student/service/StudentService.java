package com.student.service;

import java.util.List;

import com.student.exception.BusinessException;
import com.student.model.Student;

public interface StudentService {
	public Student createStudent(Student student) throws BusinessException;
	public Student getStudentById(int id) throws BusinessException;
	public Student updateStudent(Student student) throws BusinessException;
	public List<Student> getAllStudents();
	public List<Student> getStudentsByName(String name);
	
	
 
}
