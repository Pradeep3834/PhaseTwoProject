package com.student.service.impl;

import java.util.List;

import com.student.dao.TeachersDAO;
import com.student.dao.impl.TeachersDAOImpl;
import com.student.exception.BusinessException;
import com.student.model.Teachers;
import com.student.service.TeachersService;

public class TeachersServiceImpl implements TeachersService {

private TeachersDAO teachersDAO=new TeachersDAOImpl();
	
	public Teachers createTeachers(Teachers teachers) throws BusinessException {
		
		return teachersDAO.createTeachers(teachers);
	}

	public Teachers getTeachersById(int id) throws BusinessException {
		if(id<=0||id>100) {
			throw new BusinessException("entered id "+id+" invalid");
		}
		return teachersDAO.getTeachersById(id);
	}

	@Override
	public List<Teachers> getAllTeachers() {
		// TODO Auto-generated method stub
		return teachersDAO.getAllTeachers();
	}
}


