package com.student.service.impl;

import java.util.List;

import com.student.dao.StudentDAO;
import com.student.dao.impl.StudentDAoImpl;
import com.student.exception.BusinessException;
import com.student.model.Student;
import com.student.service.StudentService;

public class StudentServiceImpl implements StudentService {
private StudentDAO studentDAO=new StudentDAoImpl();
	
	@Override
	public Student createStudent(Student student) throws BusinessException {
		
		return studentDAO.createStudent(student);
	}

	@Override
	public Student getStudentById(int id) throws BusinessException {
		if(id<=0||id>100) {
			throw new BusinessException("entered id "+id+" invalid");
		}
		return studentDAO.getStudentById(id);
	}
	
	@Override
	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
		return studentDAO.getAllStudents();
	}


	@Override
	public Student updateStudent(Student student) throws BusinessException {
		
		return null;
	}

	@Override
	public List<Student> getStudentsByName(String name) {
		// TODO Auto-generated method stub
		return studentDAO.getStudentByName();
	}




}
