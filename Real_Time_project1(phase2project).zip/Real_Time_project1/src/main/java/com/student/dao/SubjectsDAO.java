package com.student.dao;

import java.util.List;

import com.student.exception.BusinessException;
import com.student.model.Subjects;

public interface SubjectsDAO {
	public Subjects createSubjects(Subjects subjects) throws BusinessException;
	public Subjects getSubjectsById(int id) throws BusinessException;

	public List<Subjects> getAllSubjects();
}
