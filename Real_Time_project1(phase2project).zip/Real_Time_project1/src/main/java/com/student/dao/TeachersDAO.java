package com.student.dao;

import java.util.List;

import com.student.exception.BusinessException;
import com.student.model.Teachers;

public interface TeachersDAO {
	public Teachers createTeachers(Teachers teachers) throws BusinessException;
	public Teachers getTeachersById(int id) throws BusinessException;
	public List<Teachers> getAllTeachers();
}
