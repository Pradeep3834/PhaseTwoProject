package com.student.dao;

import java.util.List;

import com.student.exception.BusinessException;
import com.student.model.Classes;

public interface ClassesDAO {
	public Classes createClasses(Classes classes) throws BusinessException;
	public Classes getClassesById(int id) throws BusinessException;
	public List<Classes> getAllClasses();
	
}
